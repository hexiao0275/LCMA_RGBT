from .nms_rotated_wrapper import obb_nms, poly_nms

__all__ = ['obb_nms', 'poly_nms']
